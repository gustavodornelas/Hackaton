import './styles.css'



export function Header(){
    

return (
    <div className="header">
        <div className="img">
        <img src="../../src/assets/logo.png" alt=""/>
    </div>
    <div className='line'></div>
    </div>
)
}
